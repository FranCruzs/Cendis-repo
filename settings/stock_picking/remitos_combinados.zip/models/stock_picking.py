from odoo import models, fields, api, _
from odoo.exceptions import UserError

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    def action_combine_pickings(self):
        """
        Combina los remitos seleccionados en un nuevo remito de salida
        Agrupa todos los productos, cantidades, unidades de medida
        """
        pickings = self.browse(self.env.context.get('active_ids', []))
        
        if not pickings:
            raise UserError(_("Debe seleccionar al menos un remito para combinar."))
        
        # Verificar permisos
        if not self.env.user.has_group('stock.group_stock_user'):
            raise UserError(_("No tiene permisos para realizar esta acción."))
        
        # Verificar que todos los remitos sean del mismo tipo (operación)
        picking_types = pickings.mapped('picking_type_id')
        if len(picking_types) > 1:
            raise UserError(_("No se pueden combinar remitos de diferentes tipos de operación."))
        
        # Verificar que todos los remitos tengan el mismo origen/destino
        locations = pickings.mapped('location_id')
        dest_locations = pickings.mapped('location_dest_id')
        
        if len(locations) > 1 or len(dest_locations) > 1:
            raise UserError(_("No se pueden combinar remitos con diferentes ubicaciones de origen/destino."))
        
        # Crear un nuevo remito
        new_picking = self.env['stock.picking'].create({
            'picking_type_id': picking_types.id,
            'location_id': locations.id,
            'location_dest_id': dest_locations.id,
            'origin': ', '.join(pickings.mapped('name')),
            'move_type': 'direct',
        })
        
        # Agrupar todas las líneas de los remitos seleccionados
        product_data = {}
        
        # Recorrer todos los movimientos de los remitos seleccionados
        for picking in pickings:
            for move in picking.move_ids_without_package:
                key = (move.product_id.id, move.product_uom.id)
                if key in product_data:
                    # Sumar cantidades si el producto ya existe
                    product_data[key]['product_uom_qty'] += move.product_uom_qty
                else:
                    # Crear nueva entrada para el producto
                    product_data[key] = {
                        'product_id': move.product_id.id,
                        'name': move.product_id.name,
                        'product_uom_qty': move.product_uom_qty,
                        'product_uom': move.product_uom.id,
                        'location_id': locations.id,
                        'location_dest_id': dest_locations.id,
                        'picking_id': new_picking.id,
                    }
        
        # Crear los movimientos en el nuevo remito
        for vals in product_data.values():
            self.env['stock.move'].create(vals)
        
        # Abrir el nuevo remito creado
        return {
            'name': _('Remito Combinado'),
            'view_mode': 'form',
            'res_model': 'stock.picking',
            'res_id': new_picking.id,
            'type': 'ir.actions.act_window',
            'target': 'current',
        }